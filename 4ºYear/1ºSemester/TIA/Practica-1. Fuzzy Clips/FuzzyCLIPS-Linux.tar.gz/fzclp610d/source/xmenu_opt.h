/*  $Header: /dist/CVS/fzclips/src/xmenu_opt.h,v 1.3 2001/08/11 21:08:37 dave Exp $  */

/********** local functions visible outside this file **********/
void OptionsWindow(Widget,XtPointer,XtPointer);
void SetStrategyCallback(Widget,XtPointer,XtPointer);
void SetSalienceCallback(Widget,XtPointer,XtPointer);
void OkayOptionsCallback(Widget,XtPointer,XtPointer);

