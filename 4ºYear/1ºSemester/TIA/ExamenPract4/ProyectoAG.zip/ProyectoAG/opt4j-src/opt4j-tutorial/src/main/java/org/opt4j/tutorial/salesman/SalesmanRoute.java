package org.opt4j.tutorial.salesman;

import java.util.ArrayList;

import org.opt4j.tutorial.salesman.SalesmanProblem.City;

@SuppressWarnings("serial")
public class SalesmanRoute extends ArrayList<City> {

}
