 

/**
 * The operator example shows how to add own
 * {@link org.opt4j.core.optimizer.Operator}s for the modification of
 * {@link org.opt4j.core.Genotype}s. The operator is implemented in
 * {@link org.opt4j.tutorial.operator.MyOperator} and bound using
 * {@link org.opt4j.tutorial.operator.MyOperatorModule}.
 */
package org.opt4j.tutorial.operator;

