 

/**
 * The helloworld example is a simple problem which shows the implementation of
 * the {@link org.opt4j.core.problem.Decoder},
 * {@link org.opt4j.core.problem.Evaluator} and
 * {@link org.opt4j.core.problem.Creator} interfaces which is the minimum
 * requirement for own optimization problems.
 */
package org.opt4j.tutorial.helloworld;

