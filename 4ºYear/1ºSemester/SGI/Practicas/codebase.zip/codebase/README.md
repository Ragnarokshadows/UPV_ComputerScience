# codebase <br>
código base para programación OpenGL 2.1 Win32 desktop <br>
./bin DLLs-Encaminar con variable PATH <br>
./lib Bibliotecas-Encaminar con hoja de propiedades del user en VS <br>
./include Cabeceras-Encaminar con hoja de propiedades del user en VS <br>
