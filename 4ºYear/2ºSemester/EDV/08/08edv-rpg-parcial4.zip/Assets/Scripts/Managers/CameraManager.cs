﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Cinemachine;

public class CameraManager : MonoBehaviour
{
    public static CameraManager instance;

    [HideInInspector]
    public CinemachineVirtualCamera virtualCamera;
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            GameObject vCamGO = GameObject.FindWithTag("VirtualCamera");
            virtualCamera = vCamGO.GetComponent<CinemachineVirtualCamera>();
        }
    }
}
