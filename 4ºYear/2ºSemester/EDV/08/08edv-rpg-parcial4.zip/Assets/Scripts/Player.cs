﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Character
{

    private void Start()
    {
        hitPoints.health = hitPoints.startingHealth;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("CanBePickedUp"))
        {
            Item item = other.gameObject.GetComponent<Consumable>().item;
            if (item != null)
            {
                Debug.Log("Item: " + item.objectName);

                bool shouldDisappear = false;                
                switch (item.itemType)
                {
                    case Item.ItemType.COIN:
                        shouldDisappear = Inventory.instance.AddItem(item);
                        break;
                    case Item.ItemType.HEALTH:
                        if (hitPoints.health < hitPoints.maxHealth) { 
                            AdjustHitPoints(item.quantity);
                            shouldDisappear = true;
                        }
                        break;
                }
                if (shouldDisappear)
                    other.gameObject.SetActive(false);
            }
        }
    }

    public void AdjustHitPoints(int amount)
    {
        hitPoints.health += amount;
        Debug.Log("Health: " + hitPoints.health);
    }

}
