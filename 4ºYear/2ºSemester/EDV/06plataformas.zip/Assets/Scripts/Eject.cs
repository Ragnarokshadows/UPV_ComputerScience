﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Eject : MonoBehaviour
{
    public float springForce = 30.0f;
    private Animator _anim;

    void Start()
    {
        _anim = GetComponent<Animator>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlatformerPlayer player = other.GetComponent<PlatformerPlayer>();
            player.Jump(springForce, true);
            _anim.SetTrigger("extend");
        }
    }

}
