﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxHorizontal : MonoBehaviour
{
    private float startPosition;
    private Transform cam;
    public float parallaxFraction;

    void Start()
    {
        startPosition = transform.position.x;
        cam = Camera.main.transform;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        float offset = (cam.position.x * parallaxFraction);
        Vector3 newpos = transform.position;
        newpos.x = startPosition + offset;
        transform.position = newpos;
    }
}
