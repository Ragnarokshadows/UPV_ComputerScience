﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MissileThrower : Enemy
{

    public float fireCadence;
    public float animationCycleOffset = 0.0f;

    private float timeOfLastSpawn;
    private Animator anim;

    protected override void OnWake()
    {
        anim = GetComponentInParent<Animator>();
        anim.SetFloat("CycleOffset", animationCycleOffset);
        CameraManager.Instance.UseCamera("Boss");
    }

    protected override void OnDie()
    {
        Debug.Log("MissileThrower dead");
        anim.SetTrigger("Die");
        if (FindObjectsOfType<MissileThrower>().Length == 1)
        {
            CameraManager.Instance.UseCamera("FollowPlayer");
        }
    }

    protected override void OnHit(int damage)
    {
        anim.SetTrigger("Hit");
        Debug.Log("MT Hit");
    }

    void Update()
    {
        if (!sleeping)
        {
            timeOfLastSpawn += Time.deltaTime;
            if (timeOfLastSpawn >= fireCadence)
            {
                ObjectPooler.Instance.SpawnFromPool("missile-bullet", transform.position, Quaternion.identity);
                timeOfLastSpawn = 0.0f;
            }
        }
    }

}
