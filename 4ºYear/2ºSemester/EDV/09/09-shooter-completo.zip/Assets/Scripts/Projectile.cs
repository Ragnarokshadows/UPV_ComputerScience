﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public int damage;
    public string damageOnlyToTag;

    private Vector2 lowerLeft, upperRight;
    private void Start()
    {
        Bounds bounds = GetComponent<SpriteRenderer>().bounds;
        lowerLeft = bounds.min;
        upperRight = bounds.max;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (damageOnlyToTag.Length == 0 || other.CompareTag(damageOnlyToTag))
        {
            GameEntity hit = other.gameObject.GetComponentInParent<GameEntity>();
            if (hit != null)
            {
                hit.TakeDamage(damage);
            }
            Die();
        }
    }

    private void Update()
    {
        Vector2 pos = Camera.main.WorldToScreenPoint(transform.position);
        if (pos.x < -upperRight.x || pos.x > Camera.main.pixelWidth + lowerLeft.x)
            Die();
    }
    private void Die()
    {
        gameObject.SetActive(false);
    }

}