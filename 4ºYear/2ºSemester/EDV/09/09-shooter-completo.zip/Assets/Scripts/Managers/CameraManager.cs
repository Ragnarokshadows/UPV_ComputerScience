﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using Cinemachine;


[RequireComponent(typeof(CinemachineImpulseSource))]
public class CameraManager : MonoBehaviour
{
    public static CameraManager Instance = null;
    private CinemachineImpulseSource cameraShaker;

    [System.Serializable]
    public class IdVCam
    {
        public string id;
        public CinemachineVirtualCameraBase vcam;
    }
    public List<IdVCam> cameras;

    public void UseCamera(string id)
    {
        foreach (IdVCam vcam in cameras)
        {
            vcam.vcam.Priority = (id == vcam.id ? 10 : 1);
        }
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    void Start()
    {
        cameraShaker = GetComponent<CinemachineImpulseSource>();
    }

    public void ShakeCamera(int force)
    {
        cameraShaker.GenerateImpulse(force);
    }
}

