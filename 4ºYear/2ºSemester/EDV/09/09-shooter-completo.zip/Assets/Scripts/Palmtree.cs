﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Palmtree : Enemy
{
    private Animator animator;

    public Transform bulletSource;
    public float bulletForce = 10.0f;
    IEnumerator WaitAndShootWave(float delay, int numBullets, float minAngle, float maxAngle)
    {
        yield return new WaitForSeconds(delay);
        ShootWave(numBullets, minAngle, maxAngle);
    }

    public void Shoot()
    {
        ShootWave(5, Random.Range(100, 110), Random.Range(190, 210));
        StartCoroutine(WaitAndShootWave(0.2f, 4, Random.Range(100, 110), Random.Range(150, 170)));
        StartCoroutine(WaitAndShootWave(0.4f, 4, Random.Range(140, 160), Random.Range(180, 220)));
    }

    private void ShootWave(int numBullets, float minAngle, float maxAngle)
    {
        float incrAngle = (maxAngle - minAngle) / (numBullets - 1);
        for (int i = 0; i < numBullets; i++)
        {
            GameObject bullet = ObjectPooler.Instance.SpawnFromPool("coconut-bullet", bulletSource.position, bulletSource.rotation);
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

            float angle = Mathf.Deg2Rad * (minAngle + incrAngle * i);

            Vector2 dir = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
            rb.velocity = Vector2.zero;
            rb.angularVelocity = 0.0f;

            rb.AddForce(dir * bulletForce, ForceMode2D.Impulse);
        }
    }




    protected override void OnHit(int damage)
    {
        animator.SetTrigger("Hit");
    }

    public GameEntity player;
    protected override void OnWake()
    {
        animator = GetComponent<Animator>();
        animator.SetTrigger("Detected");
        CameraManager.Instance.UseCamera("Palmtree");
        if (player != null) player.OnDieEvent += PlayerDied;
    }

    private void PlayerDied()
    {
        animator.SetTrigger("PlayerDead");
    }

    protected override void OnDie()
    {
        animator.SetTrigger("Die");
        CameraManager.Instance.UseCamera("FollowPlayer");
        if (player != null) player.OnDieEvent -= PlayerDied;
    }

}
