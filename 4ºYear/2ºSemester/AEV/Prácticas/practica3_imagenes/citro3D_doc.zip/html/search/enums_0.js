var searchData=
[
  ['c3d_5fclearbits',['C3D_ClearBits',['../framebuffer_8h.html#af6b0ba609a1336282b372df6dddabe75',1,'framebuffer.h']]],
  ['c3d_5ftexenvmode',['C3D_TexEnvMode',['../texenv_8h.html#ae642decb740f1911fc318b4f17833b8c',1,'texenv.h']]]
];
