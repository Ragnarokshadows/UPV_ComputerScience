var searchData=
[
  ['immediate_2ec',['immediate.c',['../immediate_8c.html',1,'']]],
  ['internal_2eh',['internal.h',['../internal_8h.html',1,'']]]
];
