var searchData=
[
  ['spot_5fstep',['spot_step',['../lightlut_8h.html#a23e15d5e598f96cf7143f01f14ba0291',1,'lightlut.h']]]
];
