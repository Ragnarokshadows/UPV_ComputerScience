var searchData=
[
  ['tex',['tex',['../structC3D__Context.html#a65d2e5b1e6265073c80fb759316343ba',1,'C3D_Context']]],
  ['tex3dsi_5fheader',['Tex3DSi_Header',['../tex3ds_8c.html#a99529fc03f922130a8bb9d9cd3667b77',1,'tex3ds.c']]],
  ['texconfig',['texConfig',['../structC3D__Context.html#a3df51343ca0c1829f23fcdcfe69d9d04',1,'C3D_Context']]],
  ['texenv',['texEnv',['../structC3D__Context.html#a8486fedaae5bf7f482025dae985ba2a3',1,'C3D_Context']]],
  ['texenvbuf',['texEnvBuf',['../structC3D__Context.html#a6f4d132b6ca1fc9f34950906503001cb',1,'C3D_Context']]],
  ['texenvbufclr',['texEnvBufClr',['../structC3D__Context.html#afaed4c017fd633865ba04d253b27d934',1,'C3D_Context']]],
  ['texshadow',['texShadow',['../structC3D__Context.html#ad90188948cd28d5680fc62a4b699d195',1,'C3D_Context']]],
  ['top',['top',['../structTex3DS__SubTexture.html#acd4f083c3d698e0bff53f70f01752c64',1,'Tex3DS_SubTexture::top()'],['../structTex3DSi__SubTexture.html#a6cc2b79637333bff9742879bf7bf01d9',1,'Tex3DSi_SubTexture::top()']]],
  ['transferflags',['transferFlags',['../structC3D__RenderTarget__tag.html#a7376e0f77d91b78027e642fdbfd775af',1,'C3D_RenderTarget_tag']]]
];
