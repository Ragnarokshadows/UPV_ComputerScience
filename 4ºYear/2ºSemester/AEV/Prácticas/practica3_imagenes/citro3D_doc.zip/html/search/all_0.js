var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../base_8c.html#af9aace1b44b73111e15aa39f06f43456',1,'__attribute__((weak)):&#160;base.c'],['../tex3ds_8c.html#ab898071398b359603a35c202e9c65f3b',1,'__attribute__((packed)):&#160;tex3ds.c']]],
  ['_5f_5fc3d_5fcontext',['__C3D_Context',['../base_8c.html#a9a995e066df9295b40179eb0d2b8fe01',1,'base.c']]],
  ['_5fc3d_5fdefault',['_C3D_DEFAULT',['../texenv_8h.html#affd64711422e0c96e0f5dc12add1a05d',1,'texenv.h']]]
];
