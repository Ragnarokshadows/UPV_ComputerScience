var searchData=
[
  ['gaslut_5ffromarray',['GasLut_FromArray',['../fog_8h.html#aa4dce96b8bebc6f9c3894cb9a17cbe16',1,'GasLut_FromArray(C3D_GasLut *lut, const u32 data[9]):&#160;gas.c'],['../gas_8c.html#aa4dce96b8bebc6f9c3894cb9a17cbe16',1,'GasLut_FromArray(C3D_GasLut *lut, const u32 data[9]):&#160;gas.c']]],
  ['geteffect',['getEffect',['../effect_8c.html#a1103db9b2eb38139824b7f2c9b569d75',1,'effect.c']]]
];
