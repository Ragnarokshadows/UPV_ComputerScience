var searchData=
[
  ['base_5fpaddr',['base_paddr',['../structC3D__BufInfo.html#a7a18241b048de7f47cbb79093d374f59',1,'C3D_BufInfo']]],
  ['bias',['bias',['../structC3D__LightLutDA.html#afcfe6172f2eb0f6610d37c856531d5b0',1,'C3D_LightLutDA']]],
  ['blendclr',['blendClr',['../structC3D__Effect.html#a2135f19276122f785035c6914fe693e6',1,'C3D_Effect']]],
  ['block32',['block32',['../structC3D__FrameBuf.html#a5629acfe3e4bd44ce329b3a15a02a9cf',1,'C3D_FrameBuf']]],
  ['border',['border',['../structC3D__Tex.html#a79bb706122e9ba9139c685251bd62a32',1,'C3D_Tex']]],
  ['bottom',['bottom',['../structTex3DS__SubTexture.html#ae8520be2fe338c4d790f7a4f5437d993',1,'Tex3DS_SubTexture::bottom()'],['../structTex3DSi__SubTexture.html#aa721db515076dc28b60f4f6201525a11',1,'Tex3DSi_SubTexture::bottom()']]],
  ['bufcount',['bufCount',['../structC3D__BufInfo.html#aeaaf1bcaac0df6cd1750d5a7607e41c6',1,'C3D_BufInfo']]],
  ['buffers',['buffers',['../structC3D__BufInfo.html#a3305f8841fe3fbdeec639f6bfe956cb7',1,'C3D_BufInfo']]],
  ['bufinfo',['bufInfo',['../structC3D__Context.html#a0d993d8a5035bd8f950f6e2f5bb6dad2',1,'C3D_Context']]]
];
