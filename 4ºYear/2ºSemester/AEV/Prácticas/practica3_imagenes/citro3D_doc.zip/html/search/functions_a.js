var searchData=
[
  ['proctexcolorlut_5fwrite',['ProcTexColorLut_Write',['../proctex_8h.html#a56cccececc3470266d7853897623f51d',1,'ProcTexColorLut_Write(C3D_ProcTexColorLut *out, const u32 *in, int offset, int length):&#160;proctex.c'],['../proctex_8c.html#a2b28950b8e00508b8d241cc57f7ea433',1,'ProcTexColorLut_Write(C3D_ProcTexColorLut *out, const u32 *in, int offset, int width):&#160;proctex.c']]],
  ['proctexlut_5ffromarray',['ProcTexLut_FromArray',['../proctex_8h.html#a9e3d456ec182285298d8e844c852a207',1,'ProcTexLut_FromArray(C3D_ProcTexLut *lut, const float in[129]):&#160;proctex.c'],['../proctex_8c.html#a9e3d456ec182285298d8e844c852a207',1,'ProcTexLut_FromArray(C3D_ProcTexLut *lut, const float in[129]):&#160;proctex.c']]]
];
