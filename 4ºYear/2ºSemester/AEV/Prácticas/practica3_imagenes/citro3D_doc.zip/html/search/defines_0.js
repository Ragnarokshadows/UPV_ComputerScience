var searchData=
[
  ['_5fc3d_5fdefault',['_C3D_DEFAULT',['../texenv_8h.html#affd64711422e0c96e0f5dc12add1a05d',1,'texenv.h']]]
];
