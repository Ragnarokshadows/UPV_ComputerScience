var searchData=
[
  ['lightlut_5fphong',['LightLut_Phong',['../lightlut_8h.html#ad6eca56491730b63d2cf623f30e92fa4',1,'lightlut.h']]],
  ['lightlut_5fspotlight',['LightLut_Spotlight',['../lightlut_8h.html#aa02dc6bae24878f989324228a01656c0',1,'lightlut.h']]],
  ['lightlutda_5fquadratic',['LightLutDA_Quadratic',['../lightlut_8h.html#a4dca154abae51301242ea9556469e186',1,'lightlut.h']]]
];
