var searchData=
[
  ['next',['next',['../structC3D__RenderTarget__tag.html#ac3aea4e5d3e2f77f256a91fd4b1ad3a5',1,'C3D_RenderTarget_tag']]],
  ['numlights',['numLights',['../structC3D__LightEnvConf.html#a2c59f14cb3c2fb58e7593bba9d4e52de',1,'C3D_LightEnvConf']]],
  ['numsubtextures',['numSubTextures',['../structTex3DS__Texture__s.html#aebe7a64187d9a5fd599b99d8dacc557c',1,'Tex3DS_Texture_s']]]
];
