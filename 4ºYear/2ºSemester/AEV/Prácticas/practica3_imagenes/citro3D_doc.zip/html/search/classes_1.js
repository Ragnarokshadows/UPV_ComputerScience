var searchData=
[
  ['tex3ds_5fsubtexture',['Tex3DS_SubTexture',['../structTex3DS__SubTexture.html',1,'']]],
  ['tex3ds_5ftexture_5fs',['Tex3DS_Texture_s',['../structTex3DS__Texture__s.html',1,'']]],
  ['tex3dsi_5fsubtexture',['Tex3DSi_SubTexture',['../structTex3DSi__SubTexture.html',1,'']]]
];
