var searchData=
[
  ['base_2ec',['base.c',['../base_8c.html',1,'']]],
  ['base_2eh',['base.h',['../base_8h.html',1,'']]],
  ['base_5fpaddr',['base_paddr',['../structC3D__BufInfo.html#a7a18241b048de7f47cbb79093d374f59',1,'C3D_BufInfo']]],
  ['bias',['bias',['../structC3D__LightLutDA.html#afcfe6172f2eb0f6610d37c856531d5b0',1,'C3D_LightLutDA']]],
  ['blendclr',['blendClr',['../structC3D__Effect.html#a2135f19276122f785035c6914fe693e6',1,'C3D_Effect']]],
  ['block32',['block32',['../structC3D__FrameBuf.html#a5629acfe3e4bd44ce329b3a15a02a9cf',1,'C3D_FrameBuf']]],
  ['border',['border',['../structC3D__Tex.html#a79bb706122e9ba9139c685251bd62a32',1,'C3D_Tex']]],
  ['bottom',['bottom',['../structTex3DS__SubTexture.html#ae8520be2fe338c4d790f7a4f5437d993',1,'Tex3DS_SubTexture::bottom()'],['../structTex3DSi__SubTexture.html#aa721db515076dc28b60f4f6201525a11',1,'Tex3DSi_SubTexture::bottom()']]],
  ['bufcount',['bufCount',['../structC3D__BufInfo.html#aeaaf1bcaac0df6cd1750d5a7607e41c6',1,'C3D_BufInfo']]],
  ['buffer_5fbase_5fpaddr',['BUFFER_BASE_PADDR',['../buffers_8c.html#abbe2effeef5ab2b53c5002dfd7dacfd2',1,'buffers.c']]],
  ['buffers',['buffers',['../structC3D__BufInfo.html#a3305f8841fe3fbdeec639f6bfe956cb7',1,'C3D_BufInfo']]],
  ['buffers_2ec',['buffers.c',['../buffers_8c.html',1,'']]],
  ['buffers_2eh',['buffers.h',['../buffers_8h.html',1,'']]],
  ['bufinfo',['bufInfo',['../structC3D__Context.html#a0d993d8a5035bd8f950f6e2f5bb6dad2',1,'C3D_Context']]],
  ['bufinfo_5fadd',['BufInfo_Add',['../buffers_8h.html#ace3c32831df0d7cbe2890990a5d06749',1,'BufInfo_Add(C3D_BufInfo *info, const void *data, ptrdiff_t stride, int attribCount, u64 permutation):&#160;buffers.c'],['../buffers_8c.html#ace3c32831df0d7cbe2890990a5d06749',1,'BufInfo_Add(C3D_BufInfo *info, const void *data, ptrdiff_t stride, int attribCount, u64 permutation):&#160;buffers.c']]],
  ['bufinfo_5finit',['BufInfo_Init',['../buffers_8h.html#a6bd7a8fb0f9a2922c4d3f27bbe14dc4a',1,'BufInfo_Init(C3D_BufInfo *info):&#160;buffers.c'],['../buffers_8c.html#a6bd7a8fb0f9a2922c4d3f27bbe14dc4a',1,'BufInfo_Init(C3D_BufInfo *info):&#160;buffers.c']]]
];
