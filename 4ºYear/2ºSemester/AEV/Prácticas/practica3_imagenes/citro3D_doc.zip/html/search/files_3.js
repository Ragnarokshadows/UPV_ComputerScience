var searchData=
[
  ['drawarrays_2ec',['drawArrays.c',['../drawArrays_8c.html',1,'']]],
  ['drawelements_2ec',['drawElements.c',['../drawElements_8c.html',1,'']]]
];
