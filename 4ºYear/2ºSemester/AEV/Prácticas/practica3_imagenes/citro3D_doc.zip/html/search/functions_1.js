var searchData=
[
  ['addrisvram',['addrIsVRAM',['../texture_8c.html#a4ad58cfcaf01a033b309fd8f90d17f80',1,'texture.c']]],
  ['align',['ALIGN',['../texture_8h.html#a8f7322e69691a4454af21c3612c2203a',1,'texture.h']]],
  ['allocfree',['allocFree',['../texture_8c.html#ade06802c95b8e2f936aa41bc2f78aef2',1,'texture.c']]],
  ['attrinfo_5faddfixed',['AttrInfo_AddFixed',['../attribs_8h.html#a7ef5c674515715bc56c3d585ba3e729d',1,'AttrInfo_AddFixed(C3D_AttrInfo *info, int regId):&#160;attribs.c'],['../attribs_8c.html#a7ef5c674515715bc56c3d585ba3e729d',1,'AttrInfo_AddFixed(C3D_AttrInfo *info, int regId):&#160;attribs.c']]],
  ['attrinfo_5faddloader',['AttrInfo_AddLoader',['../attribs_8h.html#a4e2e4bdce8a218aa36b168e61a081c21',1,'AttrInfo_AddLoader(C3D_AttrInfo *info, int regId, GPU_FORMATS format, int count):&#160;attribs.c'],['../attribs_8c.html#a4e2e4bdce8a218aa36b168e61a081c21',1,'AttrInfo_AddLoader(C3D_AttrInfo *info, int regId, GPU_FORMATS format, int count):&#160;attribs.c']]],
  ['attrinfo_5finit',['AttrInfo_Init',['../attribs_8h.html#aa0f970274110d97b21d52d89bd7d0ba5',1,'AttrInfo_Init(C3D_AttrInfo *info):&#160;attribs.c'],['../attribs_8c.html#aa0f970274110d97b21d52d89bd7d0ba5',1,'AttrInfo_Init(C3D_AttrInfo *info):&#160;attribs.c']]]
];
