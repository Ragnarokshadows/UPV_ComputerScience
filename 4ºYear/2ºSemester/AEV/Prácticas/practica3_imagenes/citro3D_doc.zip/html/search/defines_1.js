var searchData=
[
  ['buffer_5fbase_5fpaddr',['BUFFER_BASE_PADDR',['../buffers_8c.html#abbe2effeef5ab2b53c5002dfd7dacfd2',1,'buffers.c']]]
];
