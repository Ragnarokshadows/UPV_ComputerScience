var searchData=
[
  ['effect_2ec',['effect.c',['../effect_8c.html',1,'']]],
  ['effect_2eh',['effect.h',['../effect_8h.html',1,'']]]
];
