var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../base_8c.html#af9aace1b44b73111e15aa39f06f43456',1,'__attribute__((weak)):&#160;base.c'],['../tex3ds_8c.html#ab898071398b359603a35c202e9c65f3b',1,'__attribute__((packed)):&#160;tex3ds.c']]]
];
