var searchData=
[
  ['write24',['write24',['../immediate_8c.html#aa165195fad4a33be002502a62316a92c',1,'immediate.c']]]
];
