var searchData=
[
  ['bufinfo_5fadd',['BufInfo_Add',['../buffers_8h.html#ace3c32831df0d7cbe2890990a5d06749',1,'BufInfo_Add(C3D_BufInfo *info, const void *data, ptrdiff_t stride, int attribCount, u64 permutation):&#160;buffers.c'],['../buffers_8c.html#ace3c32831df0d7cbe2890990a5d06749',1,'BufInfo_Add(C3D_BufInfo *info, const void *data, ptrdiff_t stride, int attribCount, u64 permutation):&#160;buffers.c']]],
  ['bufinfo_5finit',['BufInfo_Init',['../buffers_8h.html#a6bd7a8fb0f9a2922c4d3f27bbe14dc4a',1,'BufInfo_Init(C3D_BufInfo *info):&#160;buffers.c'],['../buffers_8c.html#a6bd7a8fb0f9a2922c4d3f27bbe14dc4a',1,'BufInfo_Init(C3D_BufInfo *info):&#160;buffers.c']]]
];
