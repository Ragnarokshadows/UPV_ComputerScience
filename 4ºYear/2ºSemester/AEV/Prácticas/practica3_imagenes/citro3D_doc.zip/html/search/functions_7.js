var searchData=
[
  ['lightlut_5ffromarray',['LightLut_FromArray',['../lightlut_8h.html#a9b8b3517fe8b867689551801a69b011a',1,'LightLut_FromArray(C3D_LightLut *lut, float *data):&#160;lightlut.c'],['../lightlut_8c.html#a9b8b3517fe8b867689551801a69b011a',1,'LightLut_FromArray(C3D_LightLut *lut, float *data):&#160;lightlut.c']]],
  ['lightlut_5ffromfunc',['LightLut_FromFunc',['../lightlut_8h.html#a5fc17b58965a82427775599c4ba5525a',1,'LightLut_FromFunc(C3D_LightLut *lut, C3D_LightLutFunc func, float param, bool negative):&#160;lightlut.c'],['../lightlut_8c.html#a5fc17b58965a82427775599c4ba5525a',1,'LightLut_FromFunc(C3D_LightLut *lut, C3D_LightLutFunc func, float param, bool negative):&#160;lightlut.c']]],
  ['lightlutda_5fcreate',['LightLutDA_Create',['../lightlut_8h.html#aae86ce8989d5bdc85c62d0fc1aa85105',1,'LightLutDA_Create(C3D_LightLutDA *lut, C3D_LightLutFuncDA func, float from, float to, float arg0, float arg1):&#160;lightlut.c'],['../lightlut_8c.html#aae86ce8989d5bdc85c62d0fc1aa85105',1,'LightLutDA_Create(C3D_LightLutDA *lut, C3D_LightLutFuncDA func, float from, float to, float arg0, float arg1):&#160;lightlut.c']]],
  ['lutid2idx',['lutid2idx',['../proctex_8c.html#a25660a72f132fce8d559e57e14aa5ca5',1,'proctex.c']]]
];
