Ejemplo de acceso directo a la memoria de vídeo.

Basado en el ejemplo de 3DS "graphics/bitmap/24bit Bitmap Example"
y en el ejemplo de Switch "applet/recording"
