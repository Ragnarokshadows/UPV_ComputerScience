/*
	Hello World example made by Aurelio Mannara for ctrulib
	This code was modified for the last time on: 12/13/2014 01:00 UTC+1

	This wouldn't be possible without the amazing work done by:
	-Smealum
	-fincs
	-WinterMute
	-yellows8
	-plutoo
	-mtheall
	-Many others who worked on 3DS and I'm surely forgetting about
*/

#include <3ds.h>
#include <stdio.h>
#include <string.h>

//This include a header containing definitions of our image
//#include "brew_bgr.h"


        u16 framebuffer_width;
        u16 framebuffer_height;
        u8 *framebuffer, *framebufferL, *framebufferR;
	// https://www.3dbrew.org/wiki/LCD_Registers#LCD_Configuration
	// 32 bits: MSB -> LSB::   alfa(8) | B (8) | G (8) | R (8)
	int x, y;
	



void asignaColors_RGBA8() { //4 bytes por pixel
	//Get the bottom screen's frame buffer
	//	u8* fb = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, NULL, NULL);


	//
	// Pantalla superior: izquierda i derecha?
	//
	framebufferL = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {    
	         framebufferL[(x + y * framebuffer_width) * 4 + 0] = 0x00;   //Alfa?
                 framebufferL[(x + y * framebuffer_width) * 4 + 1] = 0x00;   //Blau!
                 framebufferL[(x + y * framebuffer_width) * 4 + 2] = 0x00;   //Verd!
		 framebufferL[(x + y * framebuffer_width) * 4 + 3] = 0xFF;   //Roig!
 	  }
	}
	/* Citra no pot fer ús dels dos buffers?? Si faig açò i lleve el consoleInit es veu este segon color */
	// Si faig el consoleInit puc vore els printfs i veig que framebufferL == framebufferR!!! Ooooooh!!!!
	// Espera gfxSet3D(true); fa la magia
	// Ara falta que ho pinte el emulador: Citra-qt té en configuració : Enable Stereoscopic ... però ... al despatx es queda bloquejat
	framebufferR = gfxGetFramebuffer(GFX_TOP, GFX_RIGHT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {    
	         framebufferR[(x + y * framebuffer_width) * 4 + 0] = 0x00;   //Alfa?
                 framebufferR[(x + y * framebuffer_width) * 4 + 1] = 0xFF;   //Blau!
                 framebufferR[(x + y * framebuffer_width) * 4 + 2] = 0x00;   //Verd!
		 framebufferR[(x + y * framebuffer_width) * 4 + 3] = 0x00;   //Roig!
	  }
	}

	//
	// Pantalla inferior
	//
	framebuffer = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
        //u8* gfxGetFramebuffer( gfxScreen_t screen, gfx3dSide_t side, u16 *width, u16 *height ) 	


	/*
         Exercici: comprobar qué es cada index o com es dispossa la memoria de video en direccions de memoria "decreixents" (?) o és pq está rotat 90º????????????? Per que no s'abarca el rango de les 324colsx230fils
	for (y=150; y < 190; y++) { 
	  for (x=1; x < 10; x++) { 
--> Pinta una barreta a les files més baixes i cap a les columnes més altes

Está rotat 90º????????????? A vore:  324colsx230
	for (y=0; y < 234; y++) { // for (y=0; y < framebuffer_height; y++)
	  for (x=0; x < 30; x++) {    // for (x=0; x < framebuffer_width; x++) {    
Pinta una barra apojà a la fila de baix pero que deixar marges als costats
	 */
	
	for (y=0; y < framebuffer_height; y++) { // for (y=0; y < framebuffer_height; y++)
	  for (x=0; x < framebuffer_width; x++) {    // for (x=0; x < framebuffer_width; x++) {    
	         framebuffer[(x + y * framebuffer_width) * 4 + 0] = 0x00;   //Alfa?
                 framebuffer[(x + y * framebuffer_width) * 4 + 1] = 0x00;   //Blau!
                 framebuffer[(x + y * framebuffer_width) * 4 + 2] = 0xFF;   //Verd!
		 framebuffer[(x + y * framebuffer_width) * 4 + 3] = 0x00;   //Roig!
	    
		 //	    	    framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565(0xFF, 0xFF, 0xFF); //RGB565(0xFF, 0x00, 0x00);
 	  }
	}

	
	/*
	for(y = 0; y < framebuffer_height*framebuffer_width; y++)
	           framebuffer[y*4] = (0x00<<16) | (0x00<<8) | 0xFF ; //BGR?   RGB8_to_565(0xFF, 0x00, 0x00);
	*/
	
}// Fi de asignaColors_RGBA8

void asignaColors_RGB565() { // 2 bytes por pixel
	//
	// Pantalla superior: izquierda i derecha?
	//
	framebufferL = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {    

	    framebufferL[(x + y * framebuffer_width) * 4 + 0] = 0xFF;   //Alfa?
                 framebufferL[(x + y * framebuffer_width) * 4 + 1] = 0x00;   //Blau!
                 framebufferL[(x + y * framebuffer_width) * 4 + 2] = 0x00;   //Verd!
	 
	    //framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565((u8)0xFF, (u8)0x00, (u8)0xFF);
 	  }
	}
	/* Citra no pot fer ús dels dos buffers?? Si faig açò i lleve el consoleInit es veu este segon color */
	// Si faig el consoleInit puc vore els printfs i veig que framebufferL == framebufferR!!! Ooooooh!!!!
	// Espera gfxSet3D(true); fa la magia
	// Ara falta que ho pinte el emulador: Citra-qt té en configuració : Enable Stereoscopic ... però ... al despatx es queda bloquejat
	framebufferR = gfxGetFramebuffer(GFX_TOP, GFX_RIGHT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {
	    
	         framebufferR[(x + y * framebuffer_width) * 4 + 0] = 0x00;   //Alfa?
                 framebufferR[(x + y * framebuffer_width) * 4 + 1] = 0x00;   //Blau!
                 framebufferR[(x + y * framebuffer_width) * 4 + 2] = 0xFF;   //Verd!
	    
		 //	    framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565((u8)0x00, (u8)0x00, (u8)0xFF);
	  }
	}

	//
	// Pantalla inferior
	//
	framebuffer = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
        //u8* gfxGetFramebuffer( gfxScreen_t screen, gfx3dSide_t side, u16 *width, u16 *height ) 	

	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {    
	    
	         framebuffer[(x + y * framebuffer_width) * 4 + 0] = 0x00;   //Alfa?
                 framebuffer[(x + y * framebuffer_width) * 4 + 1] = 0xFF;   //Blau!
                 framebuffer[(x + y * framebuffer_width) * 4 + 2] = 0x00;   //Verd!
		 // framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565((u8)0x00, (u8)0xFF, (u8)0x00);
 	  }
	}

	
	/*
	for(y = 0; y < framebuffer_height*framebuffer_width; y++)
	           framebuffer[y*4] = (0x00<<16) | (0x00<<8) | 0xFF ; //BGR?   RGB8_to_565(0xFF, 0x00, 0x00);
	*/
	
}// Fi de asignaColors_RGB565



void asignaColors_BGR8() { // 3 bytes por pixel
	//
	// Pantalla superior: izquierda i derecha?
	//
	framebufferL = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {    
	    framebufferL[(x + y * framebuffer_width) * 3 + 0] = 0xFF;   //Green
            framebufferL[(x + y * framebuffer_width) * 3 + 1] = 0x00;   //Red
            framebufferL[(x + y * framebuffer_width) * 3 + 2] = 0x00;   //Blue
	 
	    //framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565((u8)0xFF, (u8)0x00, (u8)0xFF);
 	  }
	}
	/* Citra no pot fer ús dels dos buffers?? Si faig açò i lleve el consoleInit es veu este segon color */
	// Si faig el consoleInit puc vore els printfs i veig que framebufferL == framebufferR!!! Ooooooh!!!!
	// Espera gfxSet3D(true); fa la magia
	// Ara falta que ho pinte el emulador: Citra-qt té en configuració : Enable Stereoscopic ... però ... al despatx es queda bloquejat
	framebufferR = gfxGetFramebuffer(GFX_TOP, GFX_RIGHT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) { 
            framebufferR[(x + y * framebuffer_width) * 3 + 0] = 0x00;   //Green
            framebufferR[(x + y * framebuffer_width) * 3 + 1] = 0x00;   //Red
            framebufferR[(x + y * framebuffer_width) * 3 + 2] = 0xFF;   //Blue	    
		 //	    framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565((u8)0x00, (u8)0x00, (u8)0xFF);
	  }
	}

	//
	// Pantalla inferior
	//
	framebuffer = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &framebuffer_width, &framebuffer_height);  //Gets the address of the framebuffer so we can draw to it
        //u8* gfxGetFramebuffer( gfxScreen_t screen, gfx3dSide_t side, u16 *width, u16 *height ) 	

	for (y=0; y < framebuffer_height; y++) { // framebuffer_height
	  for (x=0; x < framebuffer_width; x++) {    	    
	         framebuffer[(x + y * framebuffer_width) * 3 + 0] = 0x00;   //Alfa?
                 framebuffer[(x + y * framebuffer_width) * 3 + 1] = 0xFF;   //Blau!
                 framebuffer[(x + y * framebuffer_width) * 3 + 2] = 0x00;   //Verd!
		 // framebuffer[(x + y * framebuffer_width)*4] = RGB8_to_565((u8)0x00, (u8)0xFF, (u8)0x00);
 	  }
	}

	
	/*
	for(y = 0; y < framebuffer_height*framebuffer_width; y++)
	           framebuffer[y*4] = (0x00<<16) | (0x00<<8) | 0xFF ; //BGR?   RGB8_to_565(0xFF, 0x00, 0x00);
	*/
	
}// Fi de asignaColors_BGR8



#define VERLOSPRINTF 0

int main(int argc, char **argv)
{
  //gfxInitDefault();
  //Equival a gfxInit(GSP_BGR8_OES,GSP_BGR8_OES,false); @endcode
  gfxInit(GSP_BGR8_OES, GSP_BGR8_OES, true); // false --> que no es necesari el "VBlank event"

  // Puedo habilitat el efecto estereoscópico (3D) o no, pero no puedo darle un valor.
  // Ver los printfs abajo que el valor devuelto es 0.0
  gfxSet3D(true);

  gfxSetDoubleBuffering(GFX_TOP, false);
  //We don't need double buffering in this example. In this way we can draw our image only once on screen.
  // Pero si no lo hace se verá el parpadeo ("flickering")
  gfxSetDoubleBuffering(GFX_BOTTOM, false);

/* Framebuffer format ( Enumerator)
GSP_RGBA8_OES 	RGBA8. (4 bytes)
GSP_BGR8_OES 	BGR8. (3 bytes)
GSP_RGB565_OES 	RGB565. (2 bytes)
GSP_RGB5_A1_OES RGB5A1. (2 bytes)
GSP_RGBA4_OES 	RGBA4. (2 bytes) 
*/

  //asignaColors_RGBA8();
  asignaColors_BGR8();
       
  if (VERLOSPRINTF) {
	//Initialize console on top screen. Using NULL as the second argument tells the console library to use the internal console structure as current one
   	consoleInit(GFX_TOP, NULL);
	
    printf("Acceso directo a la memoria de vídeo en 3DS!");

	printf("\x1b[21;16HPress Start to exit.");
	printf("\x1b[15;01H Pantalla sup L %p: alt  %d x ample %d.", framebufferL, framebuffer_height, framebuffer_width);
	printf("\x1b[17;01H Pantalla sup R %p: alt  %d x ample %d.", framebufferR, framebuffer_height, framebuffer_width);

	printf("\x1b[18;01H osGetSliderState %f.", osGet3DSliderState() );

	printf("\x1b[19;01H Pantalla inferior %p: alt  %d x ample %d.", framebuffer, framebuffer_height, framebuffer_width);
  } //Fin de if ( VERLOSPRINTF )
	
	//Copy our image in the bottom screen's frame buffer
	//	memcpy(fb, brew_bgr, brew_bgr_size);
	//memcpy(framebuffer, _bgr, brew_bgr_size);

	
	
	// Main loop
	while (aptMainLoop())
	{
		//Scan all the inputs. This should be done once for each frame
		hidScanInput();

		//hidKeysDown returns information about which buttons have been just pressed (and they weren't in the previous frame)
		u32 kDown = hidKeysDown();

		if (kDown & KEY_START) break; // break in order to return to hbmenu

		// Flush and swap framebuffers
		gfxFlushBuffers();
		gfxSwapBuffers();

		//Wait for VBlank
		gspWaitForVBlank();
	}

	// Exit services
	gfxExit();
	return 0;
}
