#include <nds.h>
#include <fat.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

/*
 *   Ejemplo de uso del acceso al sistema de ficheros FAT para NDS
 *  y cómo probarlo sobre DesMuMe.
 * 
 * Para ejecutarlo
 *  $ make && desmume --cflash-path=./ libfatrw.nds

 *  Referencias:
 *  Reading/Writing Files. devkitPro forum.
 *  <http://devkitpro.org/viewtopic.php?f=6&t=2862&start=0>
 *
 *  Programación en C. Manejo de archivos.
 *   <http://es.wikibooks.org/wiki/Programaci%C3%B3n_en_C/Manejo_de_archivos>
 * 
 */


//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//-----------------------------------------------------------------------
 FILE *fp;
 u8 c;
	  
	// Initialise the console, required for printf
	consoleDemoInit();

        printf("Init FAT: fatInitDefault!\n");

	if(!fatInitDefault()) 
	  printf("Init FAT: Error!\n");
	else
	{
	  printf("Init FAT: conseguit!\n");   	   

 	  //
	  // Ejemplo de acceso en modo texto
	  //
	  printf("Operaciones en modo texto\n");	  
	  printf("Llegint fat:/test.txt\n");
	  fp = fopen("fat:/test.txt", "r");	 
	  if(!fp) 
	    printf("Llegint fat:/test.txt: Error!\n");
	  else
	  {
	   while (!feof( fp )) {
	     c = fgetc(fp);
	     // Provar atres coses:: char msg[100]; fscanf(f. "%s", msg);
 	     printf("%c", c);
	   }
 	   printf("\n");
	   fclose(fp);
	  }	

          printf("Escribint fat:/test.txt\n"); 
	  fp = fopen("fat:/test.txt", "w");	 
	  if(!fp) 
	    printf("Escribint fat:/test.txt: Error!\n");
	  else
	  {
	   fprintf(fp, "%s\n", "Manolo" );	   
 	   printf("\n");
	   fclose(fp);
	  }	
	  
	  //
	  // Es deixa escriure
	  // però al eixir de Desmume no es queda
	  // Encara que pots comprovar que ha canviat el contingut.
	  //
	  fp = fopen("fat:/test.txt", "r");	 
	  if(!fp) 
	    printf("Tornant a llegir fat:/test.txt: Error!\n");
	  else
	  {
	   while (!feof( fp )) {
	     c = fgetc(fp);           // Provar atres coses:: char msg[100]; fscanf(f. "%s", msg);
 	     printf("%c", c);
	   }
 	   printf("\n");
	   fclose(fp);
	  }	

	  //
	  // Acceso en modo binario
	  //
	  fp = fopen("fat:/Tetris.sav", "wb");
	  if(!fp) printf("Writing fat:/Tetris.sav: Error!\n");
			 else
			 {
			   printf("Write something to fat:/Tetris.sav\n");
			   fputc(0x78, fp);
			   fclose(fp);
			 }
			 
	 fp = fopen("fat:/Tetris.sav", "rb");
	  if(!fp) printf("Reading fat:/Tetris.sav: Error!\n");
			 else
			 {
			   u8 c = fgetc(fp);
			   fclose(fp);
			   printf("Char read: 0x%02X\n", c);
			 }
 
	} 


	while(1) {
		swiWaitForVBlank();
	}

	return 0;
}
